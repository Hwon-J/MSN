<template>
    <div>
        <h2>산출세액 : 만원</h2>
        <h2>세금감면 : (-) 만원</h2>
    </div>
</template>

<script>

export default {
  name: 'TaxRate',
  
}
</script>