<template>
  <div>
    <div>
    <span>연봉 입력 (만원): </span>
    <input type="number" v-model.number="salary">
    </div>
    <br>
    <div>
    <span>세금감면액 (만원): </span>
    <input type="text">
    </div>
    <hr>
    <div>
    <h2>종합소득금액 : {{ salary }} 만원</h2>
    <h2>종합소득공제 : (-) 150 만원</h2>
    <h2>과세표준 : {{ taxbase }} 만원</h2>
    </div>
    <hr>
    <TaxRate />
  </div>
  
</template>

<script>
import TaxRate from '@/components/TaxRate'
export default {
  name: 'InCome',
  components: {
    TaxRate,
  },
  data (){
    return{
    salary:null,
    taxrelief:null,
    }
  },
  computed:{
    taxbase: function (){
      if (this.salary-150 > 0){
        return this.salary-150
      } else {
        return 0
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
